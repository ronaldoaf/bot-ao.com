editArea.add_lang("sk",{
test_select: "vyber tag",
test_but: "testovacie tlačidlo"
});
